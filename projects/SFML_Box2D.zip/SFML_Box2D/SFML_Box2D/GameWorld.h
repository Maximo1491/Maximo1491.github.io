#ifndef _GAMEWORLD_H_
#define _GAMEWORLD_H_

#include <Box2D/Box2D.h>
#include <SFML/Graphics.hpp>
#include <SFML/System.hpp>
#include <SFML/Window.hpp>
#include <SFML/Audio.hpp>
#include "SFMLShape.h"

#define DEGTORAD 0.0174532925199432957f
#define RADTODEG 57.295779513082320876f

class GameWorld
{
  public:
    GameWorld();
    ~GameWorld();
		//Creates a new Polygon shape
    void NewPolyShape(float x, float y, const char* s, b2Vec2* v, int size, sf::Color c, bool a);
		//Creates a new Circle shape
		void NewCircleShape(float x, float y, float r, const char* s, bool a);
		//Creates a new Rectangle shape
		void NewRectShape(float x, float y, float w, float h, float a, const char* s, sf::Color c);
		//Creates a brick
		void NewBrick(float x, float y);
		//Creates a brick with a differnt width from the standard
		void NewCustomBrick(float x, float y, float w);
		//Adds a line to the screen
		void NewLine(float x, float y, float w, float h, float a);
		//Draws a castle layer which is 2 rows of bricks
		void NewCastleLayer(float x, float y);
		//Updates the world
		void UpdateWorld();
		//Draws the world
		void DrawWorld(sf::RenderWindow* w);
		//Resets the world
		void ResetWorld();

  private:
		//The Box2D world
    b2World* m_GameWorld;
		b2BodyDef* m_myBodyDef;
		b2FixtureDef* m_myFixtureDef;
		b2PolygonShape* m_pShape;
		b2CircleShape* m_cShape;
		SFMLShape* m_SFMLShape;
		//Used to check if the game should launch the player
		bool m_firePlayer;
		//Makes sure the player can only be fired once
		bool m_playerFired;
		//Draws text onto the screen
		sf::Font* m_font;
		sf::Text* m_text;
		//Plays sounds
		sf::SoundBuffer* m_soundBuffer;
		sf::Sound* m_sound;
};

#endif