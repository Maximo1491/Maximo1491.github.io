#include <GameWorld.h>
#include <sstream>

int main()
{
	//Sets up the game window
  sf::ContextSettings settings;
  settings.antialiasingLevel = 8;
	sf::RenderWindow* window = new sf::RenderWindow(sf::VideoMode(800, 600, 32), "Max is the greatest", sf::Style::Default, settings);

	//Creates a new gameworld
	GameWorld gameWorld;
	
	while (window->isOpen())
	{
		sf::Event event;
		while (window->pollEvent(event))
		{
			//Check to see if the window should close
			if (event.type == sf::Event::Closed)
				window->close();

			//Close the window when someone presses the ESC key
      if ((event.type == sf::Event::KeyPressed) && (event.key.code == sf::Keyboard::Escape))
        window->close();
		}

		//Update the world
		gameWorld.UpdateWorld();

		//Draw the world
		gameWorld.DrawWorld(window);
	}

	return 0;
}