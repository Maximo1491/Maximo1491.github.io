#include "GameWorld.h"

const float MTP = 60.0f;
const float PTM = 1/MTP;

GameWorld::GameWorld()
{
	//Makes sure the gameworld is set to null before resetting it
  m_GameWorld = NULL;
	//Creates the gameworld
  ResetWorld();

	//initialises text onto the screen
  m_text = new sf::Text();
  m_font = new sf::Font();
  m_font->loadFromFile("arial.ttf");
  m_text->setFont(*m_font);
  m_text->setString("Press R to restart\n     Click to fire!");
  m_text->setColor(sf::Color::Red);
  m_text->setPosition(-120,120);

	//initialises the sounds
	m_soundBuffer = new sf::SoundBuffer;
	m_sound = new sf::Sound;
	if(!m_soundBuffer->loadFromFile("baseball_hit.wav"))
	{
		printf("Failed to load baseball hit sound");
	}
	m_sound->setBuffer(*m_soundBuffer);
}

GameWorld::~GameWorld()
{

}

void GameWorld::NewPolyShape(float x, 
														 float y, 
														 const char* s, //Used to determine what type of body it is
														 b2Vec2* v, //The vertices of the object
														 int size, //How many vertices there are
														 sf::Color c, //The colour of the object
														 bool a) //If the object is active (if active the camera will follow that object)
{
	//The fixture def to be used by the object
  m_myFixtureDef = new b2FixtureDef();
	//The shape of the object along with its properties such as colour
	m_SFMLShape = new SFMLShape();
	m_SFMLShape->MakeActive(a);
	m_SFMLShape->NewPolyShape(c);

	//Sets the type of body the shape will use
	if(s == "Static")
	{
		m_myBodyDef->type = b2_staticBody;
	} 
	else if(s == "Dynamic")
	{
		m_myBodyDef->type = b2_dynamicBody;
	}
	else if(s == "Kinematic")
	{
		m_myBodyDef->type = b2_kinematicBody;
	}

	//Sets the position of the object (Box2D uses Meters where as SFML uses pixels so we use PTM as Pixels to Meters to convert to meters)
	m_myBodyDef->position.Set(x * PTM, y * PTM);
	//Sets the angle of the object
	m_myBodyDef->angle = 0;
	//Creates the body in the Box2D world
	b2Body* myBody = m_GameWorld->CreateBody(m_myBodyDef);

	//Sets the shape of the object in Box2D
	m_pShape->Set(v, size);
	//Sends the shape to to fixture of the object
	m_myFixtureDef->shape = m_pShape;
	//Stores the shapes properties in the userData part of Box2D
	m_myFixtureDef->userData = m_SFMLShape;
	//Sets the density of the object
	m_myFixtureDef->density = 40;
	//Adds the fixture to the body
	myBody->CreateFixture(m_myFixtureDef);
}

//Creates a new circle shape
void GameWorld::NewCircleShape(float x, float y, float r, const char* s, bool a)
{
  m_myFixtureDef = new b2FixtureDef();
	m_SFMLShape = new SFMLShape();
	m_SFMLShape->MakeActive(a);
	//Sends off a colour and a texture (if the circle is active here it applies the texture)
	m_SFMLShape->NewCircleShape(sf::Color::Red, "baseball.jpg");

	if(s == "Static")
	{
		m_myBodyDef->type = b2_staticBody;
	} 
	else if(s == "Dynamic")
	{
		m_myBodyDef->type = b2_dynamicBody;
	}
	else if(s == "Kinematic")
	{
		m_myBodyDef->type = b2_kinematicBody;
	}

	m_myBodyDef->position.Set(x * PTM, y * PTM);
	m_myBodyDef->angle = 0;
	b2Body* myBody = m_GameWorld->CreateBody(m_myBodyDef);

	m_cShape->m_p.Set(0, 0);
	m_cShape->m_radius = PTM*r ;
	m_myFixtureDef->shape = m_cShape;
	m_myFixtureDef->userData = m_SFMLShape;
	m_myFixtureDef->density = 20;
	myBody->CreateFixture(m_myFixtureDef);
}

//Draws a line into the world
void GameWorld::NewLine(float x, float y, float w, float h, float a)
{
  m_myFixtureDef = new b2FixtureDef();
	m_SFMLShape = new SFMLShape();
	m_SFMLShape->NewPolyShape(sf::Color::Green);

	m_myBodyDef->type = b2_staticBody;
	m_myBodyDef->position.Set(x * PTM, y * PTM);
	m_myBodyDef->angle = a*DEGTORAD;
	b2Body* myBody = m_GameWorld->CreateBody(m_myBodyDef);

	m_pShape->SetAsBox(PTM*w,PTM*h);
	m_myFixtureDef->shape = m_pShape;
	m_myFixtureDef->userData = m_SFMLShape;
	m_myFixtureDef->density = 20;
  m_myFixtureDef->friction = 0.8f;
	myBody->CreateFixture(m_myFixtureDef);
}

//Draws a brick
void GameWorld::NewBrick(float x, float y)
{
  m_myFixtureDef = new b2FixtureDef();
	m_SFMLShape = new SFMLShape();
	m_SFMLShape->NewBrickShape();

	m_myBodyDef->type = b2_dynamicBody;
	m_myBodyDef->position.Set(x * PTM, y * PTM);
	m_myBodyDef->angle = 0;
	b2Body* myBody = m_GameWorld->CreateBody(m_myBodyDef);

	m_pShape->SetAsBox(PTM*30,PTM*10);
	m_myFixtureDef->shape = m_pShape;
	m_myFixtureDef->userData = m_SFMLShape;
	m_myFixtureDef->density = 2;
	myBody->CreateFixture(m_myFixtureDef);
}

void GameWorld::NewCustomBrick(float x, float y, float w)
{
  m_myFixtureDef = new b2FixtureDef();
	m_SFMLShape = new SFMLShape();
	m_SFMLShape->NewBrickShape();

	m_myBodyDef->type = b2_dynamicBody;
	m_myBodyDef->position.Set(x * PTM, y * PTM);
	m_myBodyDef->angle = 0;
	b2Body* myBody = m_GameWorld->CreateBody(m_myBodyDef);

	m_pShape->SetAsBox(PTM*w,PTM*10);
	m_myFixtureDef->shape = m_pShape;
	m_myFixtureDef->userData = m_SFMLShape;
	m_myFixtureDef->density = 1;
	myBody->CreateFixture(m_myFixtureDef);
}

void GameWorld::NewCastleLayer(float x, float y)
{
	NewCustomBrick(x - 16, y - 21,14.5);
	NewBrick(x + 30, y - 21);
	NewBrick(x + 91, y - 21);
	NewBrick(x + 152, y - 21);
	NewBrick(x + 213, y - 21);
	NewCustomBrick(x + 259, y - 21 ,15);
	NewBrick(x, y);
	NewBrick(x + 61, y);
	NewBrick(x + 122, y);
	NewBrick(x + 183, y);
	NewBrick(x + 244, y);
}

void GameWorld::UpdateWorld()
{
	//Updates the box2D world
	m_GameWorld->Step((1.0f / 60.0f), 10, 8);

	//If the player presses R, reset the world
  if (sf::Keyboard::isKeyPressed(sf::Keyboard::R))
  {
    ResetWorld();
  }
	//If the player clicks, then launch the player and play the sound
  if(sf::Mouse::isButtonPressed(sf::Mouse::Left) && m_playerFired == false)
  {
		m_sound->play();
		m_firePlayer = true;
		m_playerFired = true;
  }
}

void GameWorld::ResetWorld()
{
	//If the gameworld exists then delete it
  if(m_GameWorld)
  {
    delete m_GameWorld;
		//When deleting the world like this Box2D also deletes all bodies and fixtures associated with this world
  }
  b2Vec2 gravity(0, 9.8f);
	m_GameWorld = new b2World(gravity);
	m_myBodyDef = new b2BodyDef();
	m_myFixtureDef = new b2FixtureDef();
	m_pShape = new b2PolygonShape();
	m_cShape = new b2CircleShape();
  m_playerFired = false;
  m_firePlayer = false;

  NewLine(400,550,800,1,0);
  NewLine(150,480,100,1,45);
  NewLine(-20,410,100,1,0);

  NewCastleLayer(450, 540);
	NewCastleLayer(450, 498);
	NewCastleLayer(450, 456);
	NewCastleLayer(450, 414);
	NewCastleLayer(450, 372);
	NewCastleLayer(450, 330);
	NewCastleLayer(450, 288);
	NewCastleLayer(450, 246);
  NewCastleLayer(450, 204);

  NewCircleShape(-33, 380, 20, "Dynamic", true);
}

void GameWorld::DrawWorld(sf::RenderWindow* w)
{
	//Clears the screen to black
	w->clear(sf::Color::Black);

	size_t size = 0;

	//This loops through every single body in the world
	for(b2Body* b = m_GameWorld->GetBodyList(); b; b = b->GetNext())
	{
		//This loops through every fixture in that body
		for(b2Fixture* f = b->GetFixtureList(); f; f = f->GetNext())
		{
			//If the fixture is a polygon
			if(f->GetType() == b2Shape::e_polygon)
			{
				//Gets the shape of the polygon
				b2PolygonShape* s = (b2PolygonShape*)f->GetShape();
				//Gets the shapes properties
				m_SFMLShape = (SFMLShape*)f->GetUserData();
				
				//Gets how many vertices the object has
				size = s->GetVertexCount();

				if(m_SFMLShape->Active())
				{
					//If the shape is active then setup the camera to follow the object
					sf::View view (sf::FloatRect(0, 0, 800, 600));
					view.setCenter(b->GetPosition().x*MTP, 300);
					w->setView(view);
				}

				//Sets how many vertices are in the object
				m_SFMLShape->GetPolyShape()->setPointCount(size);
				//Loops through every single vertex in a shape in box2d and sends it to SFML to be drawn
				for(unsigned int i = 0; i < size; i++)
				{
					
					b2Vec2 v = s->GetVertex(i);
					//We have to multiply all our vertices by Meters To Pixels again to convert from Box2Ds meters back to SFMLs Pixels
					m_SFMLShape->GetPolyShape()->setPoint(i, sf::Vector2f((b->GetWorldVector(v).x + b->GetPosition().x)*MTP, (b->GetWorldVector(v).y + b->GetPosition().y)*MTP));
				}

				//Drwas the shape onto the screen
				w->draw(*m_SFMLShape->GetPolyShape());
			}

			if(f->GetType() == b2Shape::e_circle)
			{
				b2CircleShape* s = (b2CircleShape*)f->GetShape();
				m_SFMLShape = (SFMLShape*)f->GetUserData();

				if(m_SFMLShape->Active())
				{
					sf::View view (sf::FloatRect(0, 0, 800, 600));
					view.setCenter(b->GetPosition().x*MTP, 300);
					w->setView(view);
					//If the player should of been fired
          if(m_firePlayer)
          {
						//Launch the player
            b->ApplyLinearImpulse(b2Vec2(125,-15), b->GetWorldCenter());
						//Set it so that the player cannot be fired again
            m_firePlayer = false;
          }
				}
        m_SFMLShape->GetCircleShape()->setRotation(b->GetAngle()*RADTODEG);
				m_SFMLShape->GetCircleShape()->setRadius(s->m_radius * MTP);
        m_SFMLShape->GetCircleShape()->setOrigin(s->m_radius * MTP, s->m_radius * MTP);
				m_SFMLShape->GetCircleShape()->setPosition((b->GetPosition().x)*MTP, (b->GetPosition().y)*MTP);

				w->draw(*m_SFMLShape->GetCircleShape());
			}
		}
	}

	//Draws the text
  w->draw(*m_text);

	//Updates the display
	w->display();
}