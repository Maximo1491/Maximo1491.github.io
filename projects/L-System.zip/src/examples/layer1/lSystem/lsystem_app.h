namespace octet
{
	//The class that contains each segment that is drawn
	class line
	{
	public:
		//The color of the segment
		material mat;
		//The shape of the segment
		mesh line_mesh;
		//The position of the segment
		mat4t modelToWorld;

		//Initialises the segment as a rectangle and brown unless otherwise stated
		void init(mat4t mToW, vec4 color = vec4(0.6f, 0.3f, 0.0f, 1))
		{
			//Sets the postion of the rectangle in the world
			modelToWorld = mToW;
			//Makes the segment a rectangle
      line_mesh.make_rectangle();
			//Sets the color of the rectangle
			mat.make_color(color, false, false);
		}

		//Renders the rectangle
		void render(bump_shader &shader, const mat4t &worldToCamera, const mat4t &cameraToProjection, vec4 *light_uniforms, int num_light_uniforms, int num_of_lights)
		{
			//Sets up the camera and projection matrices
			mat4t modelToCamera = modelToWorld * worldToCamera;
			mat4t modelToProjection = modelToCamera * cameraToProjection;
			//Sets the colour of the rectangle
			mat.render(shader, modelToProjection, modelToCamera, light_uniforms, num_light_uniforms, num_of_lights);
			//Renders the mesh of the rectangle
			line_mesh.render();
		}
	};

	//This is used for converting each char in the string ie turning F into F[+F]
	struct rule
	{
		//The char that will be changed
		char character;
		//The output of the change
		std::string implementation;
	};
	
	class lsystem_app : public app
	{
	public:
		//Stores all the rectangles that will be drawn
		dynarray<line> lines;
		
		//Sets up the camera and model matrices
		mat4t cameraToWorld;
		mat4t modelToWorld;

		//Used to keep track of where we are pushing matrices
		dynarray<mat4t> pushedMatrix;

		//The shader
		bump_shader _bump_shader;

		//The start point of the lSystem
		std::string axium;
		//How many iterations it should put through the system
		int iterations;
		//The angle to rotate by
		float angle;
		//Stores the many rules the lSystem should have
		dynarray<rule> rules;
		//The current sequence the lSystem is on
		std::string sequence;
		//The output of the lSystem after each iteration
		std::string newSequence;
		//The file that should be loaded
		char* file;

		//Keeps track if a key has been pressed
		bool keyPressed;

		lsystem_app(int argc, char **argv) : app(argc, argv) { }

		//Initialises the program
		void app_init()
		{
			//Initialises the shader
			_bump_shader.init();

			keyPressed = false;

			//Resets the camera to world and sets an initial position
			cameraToWorld.loadIdentity();
			cameraToWorld.translate(0, -370, 400);

			//Clears the console
      system("cls");

			//Prints out instructions to the console
      cout << "Welcome to Max's lSystem program\n\n"
           << "Controls:\n"
           << "Use WASD to move around the world\n"
           << "Use Q & E to tilt the camera up and down\n"
           << "Use keys 1-6 to load the differnt lSystems\n"
           << "Use the Up and Down arrow keys to iterate through\n\n"
           << "Higher implementations do cause performance issues\n"
           << "which can mean you may have to press a key multiple times.\n";
			
			//Creates a new rule
			rule r;

			//These rules are set to make sure each []+- get transfered over to the new string when iterating through
			//IE if the string comes across a [ and looks through the rules it knows to just move it over to the new string
			r.character = ']';
			r.implementation = ']';
			rules.push_back(r);

			r.character = '[';
			r.implementation = '[';
			rules.push_back(r);

			r.character = '+';
			r.implementation = '+';
			rules.push_back(r);

			r.character = '-';
			r.implementation = '-';
			rules.push_back(r);

			//Sets the intial file to be drawn
			file = "../../assets/lsystems/F.txt";
      
			//Redraws everything
			redraw();
		}

		//Draws a segment of the lSystem 
    void moveForward(bool green = false)
    {
			//Creates a new line
      line l;
			//If the segment should be brown just send its position otherwise if it is a leaf set its color to green then send the position aswell
			if(green == false)
				l.init(modelToWorld);
			else
				l.init(modelToWorld, vec4(0.0f, 1.0f, 0.0f, 1));

			//Add the line to the lines array
      lines.push_back(l);
			//Move the position in the world along for the next segment
      modelToWorld.translate(0, -8, 0);
    }

    void rotateClockwise()
    {
			//Rotates the model around the z axis
      modelToWorld.rotateZ(angle);
    }

    void rotateAntiClockwise()
    {
			//Rotates the model around the z axis
      modelToWorld.rotateZ(-angle);
    }

    void pushMatrix()
    {
			//Adds the current matrix to the pushedMatrix array, this keeps track of its current position so we can jump back to it
      pushedMatrix.push_back(modelToWorld);
    }

    void popMatrix()
    {
			//Sets the modelToWorld to the last object it the array then removes it from the array
      modelToWorld = pushedMatrix[pushedMatrix.size() - 1];
			pushedMatrix.pop_back();
    }

		void loadFile(char* c)
		{
			//Removes all the current rules in the rules array except the basic rules we set at the beginning
			while(rules[rules.size() - 1].character != '-')
			{
				rules.pop_back();
			}

			//Create a temporary variable to store the text
			std::string text;

			//Opens the file
			ifstream myfile(c);

			//Makes sure the file is open
			if(myfile.is_open())
			{
				//Loops through the whole file
				while(!myfile.eof())
				{
					//Gets the next line
					std::getline(myfile, text);

					//If the current line says that its an Axium
					if(!strcmp(text.c_str(), "Axium"))
					{
						//Get the line below and store it in the axium variable
						std::getline(myfile, axium);
					}
					//If the current line says its the iterations
					else if(!strcmp(text.c_str(), "Iterations"))
					{
						//Gets the next line and converts it into an integer and stores in the iterations variable
						std::getline(myfile, text);
						iterations = atoi(text.c_str());
					}
					//If the current line says its the Angle
					else if(!strcmp(text.c_str(), "Angle"))
					{
						//Gets the next line, converts it into a float and stores it in the angle variable
						std::getline(myfile, text);
						angle = atof(text.c_str());
					}
					//If the current line sys its a rule
					else if(!strcmp(text.c_str(), "Rule"))
					{
						//Gets the next line then goes and makes a rule
						std::getline(myfile, text);
						makeRule(text);
					}
				}
				//Once its reached the end of the file it then closes the file
				myfile.close();
			}
			//If the file could not be opened, we output a message saying this to the console
			else
			{
				cout << "Unable to open file";
			}
		}

		//Makes a rule
		void makeRule(std::string s)
		{
			//Makes a new rule variable
			rule r;

			//If the second and third character are -> then we know everything after this is a rule
			if(s[1] == '-' && s[2] == '>')
			{
				//Stores the first character in the rule so we know what we are looking for when we convert the sequence
				r.character = s[0];
				//Deletes the first 3 chars in the string
				s.erase(0, 3);
				//Gets everything else that is left in the string and stores it as the implementation
				r.implementation = s;
				//Adds the rule to the rules array
				rules.push_back(r);
			}
		}

		//Redraws the system after something changes ie, iterations or file
		void redraw(bool changedFile = true)
		{
			//If we have changed the file then we tell it to load the new file
			if(changedFile)
				loadFile(file);

			//Resets the position in the world
			modelToWorld.loadIdentity();

			//Makes sure there are no current lines in the world
			lines.resize(0);

			//Sets the sequence to the start point
			sequence = axium;

			//For every number of iterations
			for(int i = 0; i < iterations; i++)
			{
				//Loop through each char in the string
				for(std::string::iterator it = sequence.begin(); it < sequence.end(); it++)
				{
					//Loops through all the rules
					for(int i = 0; i < rules.size(); i++)
					{
						//If the current char in the string is equal to the rules character
						if(*it == rules[i].character)
						{
							//Add to the end of the new sequence, the implementation of the rule
							newSequence.insert(newSequence.size(), rules[i].implementation);
							break;
						}
					}
				}
				//After the string has been looped through make sure to set the sequence to this newSequence
				sequence = newSequence;
				//Resets the newSequence to be empty
				newSequence = "";
			}

			//Loops through the sequence
			for(std::string::iterator it = sequence.begin(); it < sequence.end(); it++)
			{
				//If the sequence is currently F then draw forward
				if(*it == 'F')
				{
					moveForward();
				}
				//If the sequence is currently X then draw a leaf
				else if(*it == 'X')
				{
					moveForward(true);
				}
				//If the sequence is currently [ then push the matrix
				else if(*it == '[')
				{
					pushMatrix();
				}
				//If the sequence is currently ] then pop the matrix
				else if(*it == ']')
				{
					popMatrix();
				}
				//If the sequence is currently + then rotate clockwise
				else if(*it == '+')
				{
					rotateClockwise();
				}
				//If the sequence is currently - then rotate anti-clockwise
				else if(*it == '-')
				{
					rotateAntiClockwise();
				}
			}
		}

		void checkKeyInput()
		{
			//Camera controls
			if (is_key_down('W'))
				cameraToWorld.translate(0, 0, -1.0f);

			if (is_key_down('S'))
				cameraToWorld.translate(0, 0, 1.0f);

			if (is_key_down('Q'))
				cameraToWorld.rotate(-1.0f, 1, 0, 0);

			if (is_key_down('E'))
				cameraToWorld.rotate(1.0f, 1, 0, 0);

			if (is_key_down('A'))
				cameraToWorld.rotate(-1.0f, 0, 1, 0);

			if (is_key_down('D'))
				cameraToWorld.rotate(1.0f, 0, 1, 0);

			//If the player is pressing ESC then exit the program
      if (is_key_down(27))
        exit(1);

			//If the player is holding down left then change the angle
			if (is_key_down(key_left))
			{
				angle -= 0.2f;
				cout << "Rotating";
				redraw(false);
			}

			//If the player is holding down right then change the angle
			if (is_key_down(key_right))
			{
				angle += 0.2f;
				cout << "Rotating";
				redraw(false);
			}

			//If the player is pressing up and it has not already done this yet then iterate up and redraw
			if (is_key_down(key_up) && keyPressed == false)
			{
				keyPressed = true;
				iterations++;
        cout << "\nIterating up. now on: " << iterations << "\n";
				redraw(false);
			}

			//If the player is pressing down and it has not already done this yet then iterate down and redraw
			if (is_key_down(key_down) && keyPressed == false)
			{
				keyPressed = true;
				if(iterations > 0)
					iterations--;
        cout << "\nIterating down. now on: " << iterations << "\n";
				redraw(false);
			}

			//If the player is pressing 1 then load the first file and move the camera
			if (is_key_down('1') && keyPressed == false)
			{
				keyPressed = true;
				file = "../../assets/lsystems/A.txt";
				cameraToWorld.loadIdentity();
				cameraToWorld.translate(0, -390, 400);
        cout << "\nLoading file A\n";
				redraw();
			}

			//If the player is pressing 2 then load the second file and move the camera
			if (is_key_down('2') && keyPressed == false)
			{
				keyPressed = true;
				file = "../../assets/lsystems/B.txt";
				cameraToWorld.loadIdentity();
				cameraToWorld.translate(0, -260, 270);
        cout << "\nLoading file B\n";
				redraw();
			}

			//If the player is pressing 3 then load the third file and move the camera
			if (is_key_down('3') && keyPressed == false)
			{
				keyPressed = true;
				file = "../../assets/lsystems/C.txt";
				cameraToWorld.loadIdentity();
				cameraToWorld.translate(0, -260, 270);
        cout << "\nLoading file C\n";
				redraw();
			}

			//If the player is pressing 4 then load the forth file and move the camera
			if (is_key_down('4') && keyPressed == false)
			{
				keyPressed = true;
				file = "../../assets/lsystems/D.txt";
				cameraToWorld.loadIdentity();
				cameraToWorld.translate(0, -650, 500);
				cameraToWorld.rotateX(-30);
				cameraToWorld.rotateY(1);
        cout << "\nLoading file D\n";
				redraw();
			}

			//If the player is pressing 5 then load the fifth file and move the camera
			if (is_key_down('5') && keyPressed == false)
			{
				keyPressed = true;
				file = "../../assets/lsystems/E.txt";
				cameraToWorld.loadIdentity();
				cameraToWorld.translate(0, -650, 500);
				cameraToWorld.rotateX(-30);
				cameraToWorld.rotateY(1);
        cout << "\nLoading file E\n";
				redraw();
			}

			//If the player is pressing 6 then load the sixth file and move the camera
			if (is_key_down('6') && keyPressed == false)
			{
				keyPressed = true;
				file = "../../assets/lsystems/F.txt";
				cameraToWorld.loadIdentity();
				cameraToWorld.translate(0, -370, 400);
        cout << "\nLoading file F\n";
				redraw();
			}

			//This is used to make sure if the player presses a key it only does the action once so as not to try and load a file every frame if the player is pressing a key
			if (!is_key_down(key_up) && !is_key_down(key_down) && !is_key_down('1') && !is_key_down('2') && !is_key_down('3') && !is_key_down('4') && !is_key_down('5') && !is_key_down('6'))
				keyPressed = false;
		}

		void draw_world(int x, int y, int width, int height)
		{
			//Sets up the viewport
			glViewport(x, y, width, height);

			//Clears the screen and sets the color to grey
			glClearColor(0.5f, 0.5f, 0.5f, 1);
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

			//OpenGL settings to remove unnecessary things from the screen
			glEnable(GL_DEPTH_TEST);
			glEnable(GL_CULL_FACE);
			glCullFace(GL_BACK);
			glFrontFace(GL_CW);

			//Checks the key input
			checkKeyInput();

			//Sets up the camera
			mat4t worldToCamera;
			cameraToWorld.invertQuick(worldToCamera);

			mat4t cameraToProjection;
			cameraToProjection.loadIdentity();
			cameraToProjection.frustum(0.125f, -.125f, .125f, -.125, 0.125f, 2056.0f);

			//Sets up the lighting
			vec4 lights[5];
			memset(lights, 0, sizeof(lights));
			lights[0] = vec4(0.3f, 0.3f, 0.3f, 50);
			lights[2] = vec4(0.707f, 0, 0.707f, 0) * cameraToWorld;//worldToCamera;
			lights[3] = vec4(1, 1, 1, 1);
			lights[4] = vec4(1, 0, 0, 1);
			
			//Draws every segment of the lSystem
			for (int i = 0; i < lines.size(); i++)
			{
				lines[i].render(_bump_shader, worldToCamera, cameraToProjection, lights, 5, 1);
			}
		}
	};
}