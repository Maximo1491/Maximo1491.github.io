
#define GL_APICALL inline
#define GL_APIENTRY
#include "gl3.h"
